package main

import (
	"context"
	"fmt"
	"log"
	"net/http"
	"time"

	"github.com/gorilla/mux"
	"github.com/gorilla/sessions"
	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
	"golang.org/x/crypto/bcrypt"
)

var (
	client           *mongo.Client
	databaseName     = "users"
	collection       = "users"
	passwordResetCol = "passwordReset"
	sessionSecret    = "secret"
	store            = sessions.NewCookieStore([]byte(sessionSecret))
)

type User struct {
	Email            string `bson:"email"`
	Password         string `bson:"password"`
	Verified         bool   `bson:"verified"`
	VerificationCode string `bson:"verification_code"`
}

type PasswordReset struct {
	Email      string    `bson:"email"`
	Token      string    `bson:"token"`
	Expiration time.Time `bson:"expiration"`
}

func main() {
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	clientOptions := options.Client().ApplyURI("mongodb+srv://loliklolik449:Bexmeen1111@cluster0.5sg9eqi.mongodb.net/")
	client, err := mongo.Connect(ctx, clientOptions)
	if err != nil {
		log.Fatal(err)
	}
	defer client.Disconnect(ctx)

	router := mux.NewRouter()
	router.HandleFunc("/register", registerHandler).Methods("POST")
	router.HandleFunc("/verify", verifyHandler).Methods("POST")
	router.HandleFunc("/login", loginHandler).Methods("POST")
	router.HandleFunc("/forgotpassword", forgotPasswordHandler).Methods("POST")
	router.HandleFunc("/resetpassword/{token}", resetPasswordHandler).Methods("POST")
	router.HandleFunc("/sendmail", sendMailHandler).Methods("POST")
	router.HandleFunc("/", indexHandler)

	http.Handle("/", router)
	log.Fatal(http.ListenAndServe(":8080", nil))
}
func indexHandler(w http.ResponseWriter, r *http.Request) {
	http.ServeFile(w, r, "sites/login.html")
}

func registerHandler(w http.ResponseWriter, r *http.Request) {
	// Парсинг данных из POST-запроса
	err := r.ParseForm()
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}
	email := r.FormValue("email")
	password := r.FormValue("password")

	// Генерация случайного кода подтверждения
	code := generateVerificationCode()

	// Создание нового пользователя
	newUser := User{
		Email:            email,
		Password:         password,
		Verified:         false,
		VerificationCode: code,
	}

	// Подключение к коллекции пользователей
	coll := client.Database(databaseName).Collection(collection)

	// Вставка нового пользователя в базу данных
	_, err = coll.InsertOne(context.Background(), newUser)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	// В этом месте вы можете отправить письмо с кодом подтверждения на email пользователя

	// Возвращение ответа клиенту
	w.WriteHeader(http.StatusOK)
	fmt.Fprintf(w, "Verification code has been sent to your email")
}

func verifyHandler(w http.ResponseWriter, r *http.Request) {
	email := r.FormValue("email")
	code := r.FormValue("code")

	err := verifyUser(email, code)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	w.WriteHeader(http.StatusOK)
	fmt.Fprintf(w, "User has been verified successfully")
}

func loginHandler(w http.ResponseWriter, r *http.Request) {
	email := r.FormValue("email")
	password := r.FormValue("password")

	err := authenticateUser(email, password)
	if err != nil {
		http.Error(w, err.Error(), http.StatusUnauthorized)
		return
	}

	session, _ := store.Get(r, "session")
	session.Values["email"] = email
	session.Save(r, w)

	w.WriteHeader(http.StatusOK)
	fmt.Fprintf(w, "Login successful")
}

func forgotPasswordHandler(w http.ResponseWriter, r *http.Request) {
	email := r.FormValue("email")

	token := generatePasswordResetToken()
	err := savePasswordResetToken(email, token)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	// Отправить ссылку с токеном на почту (нужно реализовать)

	w.WriteHeader(http.StatusOK)
	fmt.Fprintf(w, "Password reset link has been sent to your email")
}

func resetPasswordHandler(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	token := vars["token"]
	password := r.FormValue("password")

	err := resetPassword(token, password)
	if err != nil {
		http.Error(w, err.Error(), http.StatusInternalServerError)
		return
	}

	w.WriteHeader(http.StatusOK)
	fmt.Fprintf(w, "Password has been reset successfully")
}

func sendMailHandler(w http.ResponseWriter, r *http.Request) {
	// Логика отправки электронной почты (нужно реализовать)
}

func generateVerificationCode() string {
	// Генерация случайного кода (нужно реализовать)
	return "123456"
}

func generatePasswordResetToken() string {
	// Генерация случайного токена (нужно реализовать)
	return "resetToken"
}

func saveUser(email, password, code string) error {
	coll := client.Database(databaseName).Collection(collection)

	hashedPassword, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)
	if err != nil {
		return err
	}

	_, err = coll.InsertOne(context.TODO(), bson.M{
		"email":             email,
		"password":          hashedPassword,
		"verified":          false,
		"verification_code": code, // Здесь используем переданный код подтверждения
	})
	if err != nil {
		return err
	}
	return nil
}

func verifyUser(email, code string) error {
	coll := client.Database(databaseName).Collection(collection)

	result := coll.FindOneAndUpdate(context.TODO(), bson.M{"email": email, "verification_code": code},
		bson.M{"$set": bson.M{"verified": true}})
	if result.Err() != nil {
		return result.Err()
	}
	return nil
}

func authenticateUser(email, password string) error {
	coll := client.Database(databaseName).Collection(collection)

	var user User
	err := coll.FindOne(context.TODO(), bson.M{"email": email}).Decode(&user)
	if err != nil {
		return err
	}

	err = bcrypt.CompareHashAndPassword([]byte(user.Password), []byte(password))
	if err != nil {
		return err
	}

	return nil
}

func savePasswordResetToken(email, token string) error {
	coll := client.Database(databaseName).Collection(passwordResetCol)

	_, err := coll.InsertOne(context.TODO(), bson.M{
		"email":      email,
		"token":      token,
		"expiration": time.Now().Add(1 * time.Hour),
	})
	if err != nil {
		return err
	}
	return nil
}

func resetPassword(token, password string) error {
	coll := client.Database(databaseName).Collection(passwordResetCol)

	var resetPassword PasswordReset
	err := coll.FindOne(context.TODO(), bson.M{"token": token, "expiration": bson.M{"$gt": time.Now()}}).Decode(&resetPassword)
	if err != nil {
		return err
	}

	hashedPassword, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)
	if err != nil {
		return err
	}

	coll = client.Database(databaseName).Collection(collection)
	_, err = coll.UpdateOne(context.TODO(), bson.M{"email": resetPassword.Email},
		bson.M{"$set": bson.M{"password": hashedPassword}})
	if err != nil {
		return err
	}

	return nil
}
